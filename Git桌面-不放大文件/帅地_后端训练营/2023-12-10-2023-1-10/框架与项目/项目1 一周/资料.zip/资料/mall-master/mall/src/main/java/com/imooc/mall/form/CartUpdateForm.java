package com.imooc.mall.form;

import lombok.Data;

/**
 * Created by 廖师兄
 */
@Data
public class CartUpdateForm {

	private Integer quantity;

	private Boolean selected;
}
